# Kodi (XBMC) addon

Just install from zip (in release)